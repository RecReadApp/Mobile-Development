package id.recread.preferences

object UserPreferences {

    const val USER_PREF_NAME: String = "user_prefs"
    const val KEY_IS_LOGIN: String = "is_logged_in"

}